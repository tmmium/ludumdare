// openal_lite.h

#ifndef OPENAL_LITE_H_INCLUDED
#define OPENAL_LITE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

// ALC_VERSION_0_1
#define ALC_FALSE                                0
#define ALC_TRUE                                 1
#define ALC_NO_ERROR                             0
#define ALC_INVALID_DEVICE                       0xA001
#define ALC_INVALID_CONTEXT                      0xA002
#define ALC_INVALID_ENUM                         0xA003
#define ALC_INVALID_VALUE                        0xA004
#define ALC_OUT_OF_MEMORY                        0xA005

typedef char ALCboolean;
typedef char ALCchar;
typedef int ALCint;
typedef unsigned int ALCenum;

typedef struct ALCdevice ALCdevice;
typedef struct ALCcontext ALCcontext;

ALCenum alcGetError();

ALCdevice *alcOpenDevice(const ALCchar *devicename /*ignored*/);
void alcCloseDevice(ALCdevice *device);

ALCcontext *alcCreateContext(ALCdevice *device, const ALCint* attrlist /*ignored*/);
ALCboolean alcMakeContextCurrent(ALCcontext *context);
void alcDestroyContext(ALCcontext *context);
void alcProcessContext(ALCcontext *context);

// AL_VERSION_1_x
typedef char ALboolean;
typedef char ALchar;
typedef signed char ALbyte;
typedef unsigned char ALubyte;
typedef short ALshort;
typedef unsigned short ALushort;
typedef int ALint;
typedef unsigned int ALuint;
typedef int ALsizei;
typedef int ALenum;
typedef float ALfloat;
typedef double ALdouble;
typedef void ALvoid;

#define AL_NONE                                  0
#define AL_FALSE                                 0
#define AL_TRUE                                  1
#define AL_LOOPING                               0x1007
#define AL_BUFFER                                0x1009
#define AL_GAIN                                  0x100A
#define AL_SOURCE_STATE                          0x1010
#define AL_INITIAL                               0x1011
#define AL_PLAYING                               0x1012
#define AL_PAUSED                                0x1013
#define AL_STOPPED                               0x1014
#define AL_FORMAT_MONO8                          0x1100
#define AL_FORMAT_MONO16                         0x1101
#define AL_FORMAT_STEREO8                        0x1102
#define AL_FORMAT_STEREO16                       0x1103
#define AL_UNUSED                                0x2010
#define AL_NO_ERROR                              0
#define AL_INVALID_NAME                          0xA001
#define AL_INVALID_ENUM                          0xA002
#define AL_INVALID_VALUE                         0xA003
#define AL_INVALID_OPERATION                     0xA004
#define AL_OUT_OF_MEMORY                         0xA005

ALenum alGetError();

void alGenSources(ALsizei n, ALuint *sources);
void alDeleteSources(ALsizei n, const ALuint *sources);
void alSourcei(ALuint source, ALenum param, ALint value);
void alSourcef(ALuint source, ALenum param, ALfloat value);
void alGetSourcei(ALuint source,  ALenum param, ALint *value);
void alSourcePlay(ALuint source);
void alSourceStop(ALuint source);
void alSourceRewind(ALuint source);

void alGenBuffers(ALsizei n, ALuint *buffers);
void alDeleteBuffers(ALsizei n, const ALuint *buffers);
void alBufferData(ALuint buffer, ALenum format, const ALvoid *data, ALsizei size, ALsizei freq);
void alBufferi(ALuint buffer, ALenum param, ALint value);

#ifdef __cplusplus
}
#endif 

#endif // OPENAL_LITE_H_INCLUDED

#ifndef OPENAL_LITE_IMPLEMENTATION
#define OPENAL_LITE_IMPLEMENTATION
#endif 

#ifdef OPENAL_LITE_IMPLEMENTATION

#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")
#include <Windows.h>
#include <dsound.h>

#define ALC_MAX_SOURCE_COUNT (128)
#define ALC_MAX_BUFFER_COUNT (1024)

struct ALsource
{
   int state;
   int loop_count;
   IDirectSoundBuffer *duplicate;
};

struct ALbuffer
{
   int state;
   IDirectSoundBuffer *buffer;
};

struct ALCcontext
{
   ALCdevice *device;
   ALsource sources[ALC_MAX_SOURCE_COUNT];
   ALbuffer buffers[ALC_MAX_BUFFER_COUNT];
};

struct ALCdevice 
{
   IDirectSound *ds;
   IDirectSoundBuffer *primary;
};

static ALCcontext *current_openal_context = 0;
static ALCcontext *alcGetCurrentContext()
{
   return current_openal_context;
}

static ALCenum alc_error_code = ALC_NO_ERROR;
static void alcSetError(ALCenum err)
{
   alc_error_code = err;
}

ALCenum alcGetError()
{
   ALCenum result = alc_error_code;
   alc_error_code = ALC_NO_ERROR;
   return result;
}

ALCdevice *alcOpenDevice(const ALCchar * /*devicename*/)
{
   HRESULT hr = DS_OK;
   IDirectSound *ds = 0;
   IDirectSoundBuffer *primary = 0;
   
   hr = DirectSoundCreate(0, &ds, 0);
   if (hr != DS_OK) { return 0; }

   hr = ds->SetCooperativeLevel(GetForegroundWindow(), DSSCL_PRIORITY);
   if (hr != DS_OK) { ds->Release(); return 0; }

   DSBUFFERDESC desc = {};
   desc.dwSize = sizeof(DSBUFFERDESC);
   desc.dwFlags = DSBCAPS_PRIMARYBUFFER;

   hr = ds->CreateSoundBuffer(&desc, &primary, 0);
   if (hr != DS_OK) { ds->Release(); return 0; }

   WAVEFORMATEX format = {};
   format.cbSize = sizeof(WAVEFORMATEX);
   format.wFormatTag = WAVE_FORMAT_PCM;
   format.nChannels = 2;
   format.nSamplesPerSec = 44100;
   format.wBitsPerSample = sizeof(short) * 8;
   format.nBlockAlign = (format.nChannels * format.wBitsPerSample) / 8;
   format.nAvgBytesPerSec = (format.nSamplesPerSec * format.nBlockAlign);

   hr = primary->SetFormat(&format);
   if (hr != DS_OK) { primary->Release(); ds->Release(); return 0; }

   ALCdevice *device = (ALCdevice *)_aligned_malloc(sizeof(ALCdevice), 4);
   memset(device, 0, sizeof(ALCdevice));

   device->ds = ds;
   device->primary = primary;

   return device;
}

void alcCloseDevice(ALCdevice *device)
{
   device->ds->Release();
   _aligned_free(device);
}

ALCcontext *alcCreateContext(ALCdevice *device, const ALCint * /*attrlist*/)
{
   ALCcontext *context = (ALCcontext *)_aligned_malloc(sizeof(ALCcontext), 4);
   memset(context, 0, sizeof(ALCcontext));

   context->device = device;

   return context;
}

ALCboolean alcMakeContextCurrent(ALCcontext *context)
{
   current_openal_context = context;

   return AL_TRUE;
}

void alcDestroyContext(ALCcontext *context)
{
   // release all sources
   for (int i = 0; i < ALC_MAX_SOURCE_COUNT; i++)
   {
      ALsource *src = context->sources + i;
      if (!src->state) 
      { 
         continue; 
      }

      if (src->duplicate) 
      { 
         src->duplicate->Stop();
         src->duplicate->Release(); 
      }

      src->duplicate = 0;
      src->state = 0;
      src->loop_count = 0;
   }

   // release all buffers
   for (int i = 0; i < ALC_MAX_BUFFER_COUNT; i++)
   {
      ALbuffer *buf = context->buffers + i;
      if (buf->buffer)
      {
         buf->buffer->Release();
      }

      buf->buffer = 0;
   }

   _aligned_free(context);
}

void alcProcessContext(ALCcontext *context)
{
   for (int i = 0; i < ALC_MAX_SOURCE_COUNT; i++)
   {
      ALsource *src = context->sources + i;
      if (!src->state) { continue; }

      HRESULT hr = DS_OK;
      DWORD status = 0;
      hr = src->duplicate->GetStatus(&status);

      bool is_playing = (status & DSBSTATUS_PLAYING) != 0;
      if (!is_playing)
      {
         if (src->loop_count > 0)
         {
            src->duplicate->Play(0, 0, 0);
            src->state = AL_PLAYING;
            src->loop_count--;
         }
         else 
         {
            src->duplicate->Release();
            src->duplicate = 0;
            src->state = 0;
            src->loop_count = 0;
         }
      }
   }
}

// AL_VERSION_1_x
static ALenum al_error_code = AL_NO_ERROR;
static void alSetError(ALenum err)
{
   al_error_code = err;
}

ALenum alGetError()
{
   ALenum result = al_error_code;
   al_error_code = AL_NO_ERROR;
   return result;
}

void alGenSources(ALsizei n, ALuint *sources)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   int sources_available_count = 0;
   for (int i = 0, k = 0; (i < ALC_MAX_SOURCE_COUNT) && (k < n); i++)
   {
      ALsource *src = context->sources + i;
      if (!src->duplicate && !src->state)
      {
         src->state = AL_INITIAL;
         sources_available_count++;
         sources[k++] = i + 1;
      }
   }

   if (sources_available_count < n)
   {
      for (int i = 0; i < sources_available_count; i++)
      {
         (context->sources + sources[i])->state = 0;
         sources[i] = 0;
      }

      alSetError(AL_INVALID_OPERATION);
   }
}

void alDeleteSources(ALsizei n, const ALuint *sources)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }
   
   for (int i = 0; i < n; i++)
   {
      ALsource *src = context->sources + sources[i];

      if (src->duplicate)
      {
         src->duplicate->Release();
      }

      src->duplicate = 0;
      src->state = 0;
      src->loop_count = 0;
   }
}

void alSourcei(ALuint source, ALenum param, ALint value)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   ALsource *src = context->sources + (source - 1);
   if (src->duplicate)
   {
      // todo: what to do?
      //src->duplicate->Stop();
      //src->duplicate->Release();
      alSetError(AL_INVALID_OPERATION);
      return;
   }

   if (param == AL_BUFFER)
   {
      ALbuffer *buf = context->buffers + (value - 1);
      if (buf->buffer)
      {
         HRESULT hr = DS_OK;
         hr = context->device->ds->DuplicateSoundBuffer(buf->buffer, &src->duplicate);
         if (hr != DS_OK)
         {
            src->duplicate->Release();
            src->duplicate = 0;
            src->state = 0;
            src->loop_count = 0;
            alSetError(AL_INVALID_OPERATION);
            return ;
         }
         else 
         {
            src->state = AL_INITIAL;
         }
      }
      else 
      {
         alSetError(AL_INVALID_VALUE);
         return;
      }
   }
}

void alSourcef(ALuint source, ALenum param, ALfloat value)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   ALsource *src = context->sources + (source - 1);
   if (param == AL_GAIN)
   {
      //src->duplicate->SetVolume();
   }
}

void alGetSourcei(ALuint source, ALenum param, ALint *value)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   ALsource *src = context->sources + (source - 1);
   if (param == AL_SOURCE_STATE)
   {
      *value = src->state;
   }
}

void alSourcePlay(ALuint source)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   ALsource *src = context->sources + (source - 1);
   if (!src->duplicate)
   {
      alSetError(AL_INVALID_VALUE);
      return;
   }

   src->duplicate->Play(0, 0, 0);
   src->state = AL_PLAYING;
}

void alSourceStop(ALuint source)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   ALsource *src = context->sources + (source - 1);
   if (!src->duplicate)
   {
      alSetError(AL_INVALID_VALUE);
      return;
   }

   src->duplicate->Stop();
   src->state = AL_STOPPED;
}

void alSourceRewind(ALuint source)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   // no-op
}

void alGenBuffers(ALsizei n, ALuint *buffers)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   int buffers_available_count = 0;
   for (int i = 0, k = 0; (i < ALC_MAX_BUFFER_COUNT) && (k < n); i++)
   {
      ALbuffer *buf = context->buffers + i;
      if (!buf->buffer && !buf->state)
      {
         buf->state = 1;
         buffers_available_count++;
         buffers[k++] = i + 1;
      }
   }

   if (buffers_available_count < n)
   {
      for (int i = 0; i < buffers_available_count; i++)
      {
         (context->buffers + buffers[i])->state = 0;
         buffers[i] = 0;
      }

      alSetError(AL_INVALID_OPERATION);
   }
}

void alDeleteBuffers(ALsizei n, const ALuint *buffers)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   ALbuffer *buf = context->buffers + (n - 1);
   if (buf->buffer)
   {
      buf->buffer->Release();
      buf->buffer = 0;
      buf->state = 0;
   }
}

static int alxGetFormatChannelCount(ALenum format)
{
   switch (format)
   {
      case AL_FORMAT_MONO8:
      case AL_FORMAT_MONO16:
         return 1;
      break;
      case AL_FORMAT_STEREO8:
      case AL_FORMAT_STEREO16:
         return 2;
      break;
   }

   return 0;
}

static int alxGetBitsPerSample(ALenum format)
{
   switch (format)
   {
      case AL_FORMAT_MONO8:
      case AL_FORMAT_STEREO8:
         return 8;
      case AL_FORMAT_MONO16:
      case AL_FORMAT_STEREO16:
         return 16;
   }

   return 0;
}

void alBufferData(ALuint buffer, ALenum format, const ALvoid *data, ALsizei size, ALsizei freq)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }

   ALbuffer *buf = context->buffers + (buffer - 1);
   if (buf->buffer)
   {
      buf->buffer->Release();
      buf->buffer = 0;
   }

   HRESULT hr = DS_OK;
   
   WAVEFORMATEX wave = {};
   wave.cbSize = sizeof(WAVEFORMATEX);
   wave.wFormatTag = WAVE_FORMAT_PCM;
   wave.nSamplesPerSec = freq;
   wave.nChannels = alxGetFormatChannelCount(format);
   wave.wBitsPerSample = alxGetBitsPerSample(format);
   wave.nBlockAlign = wave.nChannels * wave.wBitsPerSample / 8;
   wave.nAvgBytesPerSec = wave.nSamplesPerSec * wave.nBlockAlign;

   DSBUFFERDESC desc = {};
   desc.dwSize = sizeof(DSBUFFERDESC);
   desc.dwFlags = DSBCAPS_CTRLVOLUME;
   desc.dwBufferBytes = size;
   desc.lpwfxFormat = &wave;

   hr = context->device->ds->CreateSoundBuffer(&desc, &buf->buffer, 0);
   if (hr != DS_OK)
   {
      alSetError(AL_INVALID_OPERATION);
      return;
   }

   DWORD bytes = 0;
   void *dst = 0;
   hr = buf->buffer->Lock(0, desc.dwBufferBytes, &dst, &bytes, 0, 0, 0);
   memcpy(dst, data, desc.dwBufferBytes);
   hr = buf->buffer->Unlock(dst, desc.dwBufferBytes, 0, 0);
}

void alBufferi(ALuint buffer, ALenum param, ALint value)
{
   ALCcontext *context = alcGetCurrentContext();
   if (!context) 
   {
      alcSetError(ALC_INVALID_CONTEXT);
      alSetError(AL_INVALID_OPERATION);
      return; 
   }
}

#endif // OPENAL_LITE_IMPLEMENTATION
