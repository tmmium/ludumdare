// audio.c

#ifndef AUDIO_H_INCLUDED
#define AUDIO_H_INCLUDED

// todo: config
#ifdef _WIN32 
#define AUDIO_PLATFORM_WINDOWS
#endif 

#ifdef __cplusplus
extern "C" {
#endif

// config
#define AUDIO_SOURCE_COUNT             4096
#define AUDIO_ALLOCATOR_CAPACITY_MB    4

// invalid handle 
#define AUDIO_INVALID_SOURCE           0

// error codes
#define AUDIO_ERROR_NONE               0x0000
#define AUDIO_ERROR_OUT_OF_MEMORY      0x0001

// audio status codes
#define AUDIO_STATUS_NONE              0x0000
#define AUDIO_STATUS_INITIAL           0x0000
#define AUDIO_STATUS_LOADING           0x0001
#define AUDIO_STATUS_LOADED            0x0002
#define AUDIO_STATUS_PLAYING           0x0004
#define AUDIO_STATUS_PAUSED            0x0008

// types
typedef unsigned int audio_error_t;  // error codes
typedef unsigned int audio_status_t; // status flags
typedef unsigned int audio_source_t; // source reference

typedef struct audio_device_t audio_device_t;
typedef struct audio_vorbis_t audio_vorbis_t;

audio_device_t *audio_device_create(void * /*param*/);
void            audio_device_destroy(audio_device_t *dev);
audio_error_t   audio_device_get_error(audio_device_t *dev);

audio_vorbis_t *audio_vorbis_create_from_file(audio_device_t *dev, const char *filename);
void            audio_vorbis_destroy(audio_device_t *dev, audio_vorbis_t *vorbis);
audio_source_t  audio_vorbis_play(audio_device_t *dev, const audio_vorbis_t *vorbis);
void            audio_vorbis_stop(audio_device_t *dev, audio_source_t handle);
audio_status_t  audio_vorbis_get_status(audio_device_t *dev, audio_source_t handle);

#ifdef __cplusplus
}
#endif

#endif // AUDIO_H_INCLUDED

#if 1 //def AUDIO_IMPLEMENTATION

#ifdef __cplusplus
extern "C" {
#endif

#pragma warning(push)
#pragma warning(disable: 4456) // declaration of hides previous local declaration
#pragma warning(disable: 4457) // declaration of hides function parameter
#pragma warning(disable: 4245) // conversion from to, signed/unsigned mismatch
#pragma warning(disable: 4701) // potentially uninitialized local variable used
//#define STB_VORBIS_HEADER_ONLY
#define STB_VORBIS_NO_PUSHDATA_API
#define STB_VORBIS_NO_PULLDATA_API
#define STB_VORBIS_NO_STDIO
#include <stb_vorbis.h>
#pragma warning(pop)

#define ASSERT(x)                      if (!(x)) { *(int *)0=0; }
#define KILOBYTES(x)                   (1024U * (x))
#define MEGABYTES(x)                   (1024U * KILOBYTES(x))

#define AUDIO_HANDLE_TYPE_BUFFER       0x1
#define AUDIO_HANDLE_TYPE_STREAM       0x2
#define AUDIO_HANDLE_TYPE_MASK         0x3
#define AUDIO_HANDLE_TYPE_SHIFT        30
#define AUDIO_HANDLE_INDEX_MASK        0x3FFFFFFF

static void *audio__malloc(int size);
static void  audio__free(void *pointer);

typedef struct 
{
   int size;
   char *base;
   char *at;
} audio_allocator_t;

static void audio__allocator_init(audio_allocator_t *allocator, int size, char *base)
{
   allocator->size = size;
   allocator->base = base;
   allocator->at = base;
}

static void *audio__allocator_allocate(audio_allocator_t *a, int size)
{
   ASSERT((a->size - (int)(a->at - a->base)) > 0);
   void *result = a->at;
   a->at += size;
   return result;
}

typedef struct 
{
   volatile long long ticket;
   volatile long long current;
} audio_mutex_t;

static void audio__mutex_begin(audio_mutex_t *mutex);
static void audio__mutex_end(audio_mutex_t *mutex); 
static void audio__mutex_init(audio_mutex_t *mutex)
{
   mutex->ticket = 0;
   mutex->current = 0;
}

typedef struct 
{
   int size;
   char *data;
} audio_file_content_t;

static audio_file_content_t audio__read_file(const char *filename);

typedef struct audio_backend_t audio_backend_t;

static int  audio__backend_create(audio_backend_t *backend);
static void audio__backend_release(audio_backend_t *backend);
// ...

typedef struct 
{
   int count;
   char *base;
   char *at;
} audio_command_buffer_t;

static void audio__command_buffer_init(audio_command_buffer_t *buffer, char *base)
{
   buffer->count = 0;
   buffer->base = base;
   buffer->at = base;
}

static void audio__command_buffer_reset(audio_command_buffer_t *commands)
{
   commands->count = 0;
   commands->at = commands->base;
}

static void audio__command_push_command(audio_command_buffer_t *commands)
{
}

typedef struct audio_vorbis_t
{
   audio_file_content_t file_content;
   stb_vorbis *source;
   stb_vorbis_info info;
} audio_vorbis_t;

typedef struct audio_vorbis_cache_t
{
   audio_mutex_t mutex;
   int free_list_count;
   int free_list[AUDIO_SOURCE_COUNT];
   audio_vorbis_t sources[AUDIO_SOURCE_COUNT];
} audio_vorbis_cache_t;

static void audio__vorbis_cache_init(audio_vorbis_cache_t *cache)
{
   for (int i = 0; i < AUDIO_SOURCE_COUNT; i++)
   {
      cache->free_list_count++;
      cache->free_list[i] = i;
      cache->sources[i].file_content = {0};
      cache->sources[i].source = 0;
      cache->sources[i].info = {0};
   }
}

audio_error_t audio_device_get_error(audio_device_t *dev)
{
   return AUDIO_ERROR_NONE;
}

audio_vorbis_t *audio_vorbis_create_from_file(audio_device_t *dev, const char *filename)
{
   return 0;
}

void audio_vorbis_destroy(audio_device_t *dev, audio_vorbis_t *vorbis)
{

}

audio_source_t audio_vorbis_play(audio_device_t *dev, const audio_vorbis_t *vorbis)
{
   return AUDIO_INVALID_SOURCE;
}

void audio_vorbis_stop(audio_device_t *dev, audio_source_t handle)
{

}

audio_status_t audio_vorbis_get_status(audio_device_t *dev, audio_source_t handle)
{
   return AUDIO_STATUS_NONE;
}

#ifdef AUDIO_PLATFORM_WINDOWS
#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")
#include <windows.h>
#include <dsound.h>
#include <intrin.h>

static void *audio__malloc(int size)
{
   return VirtualAlloc(0, size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
}

static void audio__free(void *pointer)
{
   VirtualFree(pointer, 0, MEM_RELEASE);
}

static void audio__mutex_begin(audio_mutex_t *mutex) 
{
   long long ticket = _InterlockedExchangeAdd64(&mutex->ticket, 1);
   while(ticket != mutex->current) { Sleep(1); /*todo: replace Sleep*/}
}

static void audio__mutex_end(audio_mutex_t *mutex) 
{
   _InterlockedIncrement64(&mutex->current);
}

static audio_file_content_t audio__read_file(const char *filename)
{

}

struct audio_backend_t
{
   IDirectSound *ds;
   IDirectSoundBuffer *primary;
   IDirectSoundBuffer *buffer;
};

static int audio__backend_create(audio_backend_t *backend)
{
   HRESULT hr = DS_OK;
   IDirectSound *ds = 0;
   IDirectSoundBuffer *primary = 0;
   IDirectSoundBuffer *buffer = 0;
   
   hr = DirectSoundCreate(0, &ds, 0);
   if (hr != DS_OK) { return 0; }

   hr = ds->SetCooperativeLevel(GetForegroundWindow(), DSSCL_PRIORITY);
   if (hr != DS_OK) { ds->Release(); return 0; }

   DSBUFFERDESC desc = {};
   desc.dwSize = sizeof(DSBUFFERDESC);
   desc.dwFlags = DSBCAPS_PRIMARYBUFFER;

   hr = ds->CreateSoundBuffer(&desc, &primary, 0);
   if (hr != DS_OK) { ds->Release(); return 0; }

   WAVEFORMATEX format = {};
   format.cbSize = sizeof(WAVEFORMATEX);
   format.wFormatTag = WAVE_FORMAT_PCM;
   format.nChannels = 2;
   format.nSamplesPerSec = 44100;
   format.wBitsPerSample = sizeof(short) * 8;
   format.nBlockAlign = (format.nChannels * format.wBitsPerSample) / 8;
   format.nAvgBytesPerSec = (format.nSamplesPerSec * format.nBlockAlign);

   hr = primary->SetFormat(&format);
   if (hr != DS_OK) { primary->Release(); ds->Release(); return 0; }

   int secondary_buffer_latency = 10; // note: in ms
   desc.dwFlags = DSBCAPS_CTRLVOLUME | DSBCAPS_CTRLPAN | DSBCAPS_CTRLFREQUENCY;
   desc.dwBufferBytes = format.nSamplesPerSec / secondary_buffer_latency;
   desc.lpwfxFormat = &format;

   hr = ds->CreateSoundBuffer(&desc, &buffer, 0);
   if (hr != DS_OK) { primary->Release(); ds->Release(); return 0; }

   hr = buffer->Play(0, 0, DSBPLAY_LOOPING);
   if (hr != DS_OK) { buffer->Release(); primary->Release(); ds->Release(); return 0; }

   backend->ds = ds;
   backend->primary = primary;
   backend->buffer = buffer;

   return 1;
}

struct audio_device_t
{
   audio_backend_t backend;
   audio_mutex_t mutex;
   audio_allocator_t allocator;
   int current_command_index;
   audio_vorbis_cache_t cache;
   audio_command_buffer_t *current_command_buffer;
   audio_command_buffer_t command_buffers[2];
};

static DWORD WINAPI audio__thread_proc(void *param)
{
   audio_device_t *dev = (audio_device_t *)param;

   while(1)
   {
      audio_command_buffer_t *commands = 0;
      audio__mutex_begin(&dev->mutex);
      {
         commands = dev->current_command_buffer;
         dev->current_command_index = (dev->current_command_index + 1) % 2;
         dev->current_command_buffer = dev->command_buffers + dev->current_command_index;
      }
      audio__mutex_end(&dev->mutex);

      if (commands->count > 0)
      {
      }

      audio__command_buffer_reset(commands);

      Sleep(100);
   }

   return 0;
}

static void audio__backend_release(audio_backend_t *backend)
{
#ifdef __cplusplus
   if (backend->buffer)
      backend->buffer->Release();
   if (backend->primary)
      backend->primary->Release();
   if (backend->ds)
      backend->ds->Release();
#else
   if (backend->buffer)
      backend->buffer->lpVtbl->Release(backend->buffer);
   if (backend->primary)
      backend->primary->lpVtbl->Release(backend->primary);
   if (backend->ds)
      backend->ds->lpVtbl->Release(backend->ds);
#endif
}

audio_device_t *audio_device_create(void *params)
{
   const int allocator_capacity = MEGABYTES(AUDIO_ALLOCATOR_CAPACITY_MB);
   const int allocation_size = sizeof(audio_device_t) + allocator_capacity;
   char *base = (char *)audio__malloc(allocation_size);
   memset(base, 0, allocation_size);

   audio_device_t *dev = (audio_device_t *)base;
   audio__backend_create(&dev->backend);
   audio__mutex_init(&dev->mutex);
   audio__allocator_init(&dev->allocator, allocator_capacity, base + sizeof(audio_device_t));
   audio__vorbis_cache_init(&dev->cache);

   dev->current_command_index  = 0;
   dev->current_command_buffer = dev->command_buffers + dev->current_command_index;
   audio__command_buffer_init(dev->command_buffers + 0, 
      (char *)audio__allocator_allocate(&dev->allocator, KILOBYTES(128)));
   audio__command_buffer_init(dev->command_buffers + 1, 
      (char *)audio__allocator_allocate(&dev->allocator, KILOBYTES(128)));

   CreateThread(0, 0, audio__thread_proc, dev, 0, 0);

   return dev;
}

void audio_device_destroy(audio_device_t *dev)
{
   audio__backend_release(&dev->backend);
   audio__free(dev);
}

#endif // _WIN32

#ifdef __cplusplus
}
#endif

#endif // AUDIO_IMPLEMENTATION

