// game_api.h

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct v2i { int32_t x, y; } v2i;

typedef struct loaded_file
{
   uint32_t size;
   uint8_t *data;
} loaded_file;

typedef struct platform_api 
{
   void *(*alloc)(int size);
   void (*free)(void *pointer);
   uint32_t (*get_ticks)();
   loaded_file (*load)(const char *filename);
} platform_api;

typedef enum
{
   KEY_CANCEL,
   KEY_BACK,
   KEY_TAB,
   KEY_CLEAR,
   KEY_RETURN,
   KEY_SHIFT,
   KEY_CONTROL,
   KEY_MENU,
   KEY_PAUSE,
   KEY_CAPITAL,
   KEY_FINAL,
   KEY_ESCAPE,
   KEY_CONVERT,
   KEY_NONCONVERT,
   KEY_ACCEPT,
   KEY_MODECHANGE,
   KEY_SPACE,
   KEY_PRIOR,
   KEY_NEXT,
   KEY_END,
   KEY_HOME,
   KEY_LEFT,
   KEY_UP,
   KEY_RIGHT,
   KEY_DOWN,
   KEY_SELECT,
   KEY_PRINT,
   KEY_SNAPSHOT,
   KEY_INSERT,
   KEY_DELETE,
   KEY_HELP,
   KEY_0,
   KEY_1,
   KEY_2,
   KEY_3,
   KEY_4,
   KEY_5,
   KEY_6,
   KEY_7,
   KEY_8,
   KEY_9,
   KEY_A,
   KEY_B,
   KEY_C,
   KEY_D,
   KEY_E,
   KEY_F,
   KEY_G,
   KEY_H,
   KEY_I,
   KEY_J,
   KEY_K,
   KEY_L,
   KEY_M,
   KEY_N,
   KEY_O,
   KEY_P,
   KEY_Q,
   KEY_R,
   KEY_S,
   KEY_T,
   KEY_U,
   KEY_V,
   KEY_W,
   KEY_X,
   KEY_Y,
   KEY_Z,
   KEY_LWIN,
   KEY_RWIN,
   KEY_APPS,
   KEY_SLEEP,
   KEY_NUMPAD0,
   KEY_NUMPAD1,
   KEY_NUMPAD2,
   KEY_NUMPAD3,
   KEY_NUMPAD4,
   KEY_NUMPAD5,
   KEY_NUMPAD6,
   KEY_NUMPAD7,
   KEY_NUMPAD8,
   KEY_NUMPAD9,
   KEY_MULTIPLY,
   KEY_ADD,
   KEY_SEPARATOR,
   KEY_SUBTRACT,
   KEY_DECIMAL,
   KEY_DIVIDE,
   KEY_F1,
   KEY_F2,
   KEY_F3,
   KEY_F4,
   KEY_F5,
   KEY_F6,
   KEY_F7,
   KEY_F8,
   KEY_F9,
   KEY_F10,
   KEY_F11,
   KEY_F12,
   KEY_F13,
   KEY_F14,
   KEY_F15,
   KEY_F16,
   KEY_F17,
   KEY_F18,
   KEY_F19,
   KEY_F20,
   KEY_F21,
   KEY_F22,
   KEY_F23,
   KEY_F24,
   KEY_NUMLOCK,
   KEY_SCROLL,
   KEY_LSHIFT,
   KEY_RSHIFT,
   KEY_LCONTROL,
   KEY_RCONTROL,
   KEY_LMENU,
   KEY_RMENU,
   KEY_BROWSER_BACK,
   KEY_BROWSER_FORWARD,
   KEY_BROWSER_REFRESH,
   KEY_BROWSER_STOP,
   KEY_BROWSER_SEARCH,
   KEY_BROWSER_FAVORITES,
   KEY_BROWSER_HOME,
   KEY_VOLUME_MUTE,
   KEY_VOLUME_DOWN,
   KEY_VOLUME_UP,
   KEY_MEDIA_NEXT_TRACK,
   KEY_MEDIA_PREV_TRACK,
   KEY_MEDIA_STOP,
   KEY_MEDIA_PLAY_PAUSE,
   KEY_LAUNCH_MAIL,
   KEY_LAUNCH_MEDIA_SELECT,
   KEY_LAUNCH_APP1,
   KEY_LAUNCH_APP2,
   KEY_OEM_1,
   KEY_OEM_PLUS,
   KEY_OEM_COMMA,
   KEY_OEM_MINUS,
   KEY_OEM_PERIOD,
   KEY_OEM_2,
   KEY_OEM_3,
   KEY_OEM_4,
   KEY_OEM_5,
   KEY_OEM_6,
   KEY_OEM_7,
   KEY_OEM_8,
   KEY_OEM_102,
   KEY_PROCESSKEY,
   KEY_PACKET,
   KEY_ATTN,
   KEY_CRSEL,
   KEY_EXSEL,
   KEY_EREOF,
   KEY_PLAY,
   KEY_ZOOM,
   KEY_NONAME,
   KEY_PA1,
   KEY_OEM_CLEAR,
   KEYCODE_COUNT,
} keycode;

typedef enum 
{
   BUTTON_LEFT,
   BUTTON_RIGHT,
   MOUSE_BUTTON_COUNT,
} mouse_button;

typedef struct input_api
{
   int32_t (*key_down)(int32_t index);
   int32_t (*button_down)(mouse_button index);
   v2i (*mouse_position)();
   v2i (*mouse_movement)();
} input_api;

typedef struct game_render_command_group
{

} game_render_command_group;

#define GAME_TICK_CALLBACK(name) int name(platform_api *platform, input_api *input)
typedef GAME_TICK_CALLBACK(game_tick_callback);

#ifdef __cplusplus
}
#endif








#if 0
#ifdef __cplusplus
extern "C" {
#endif

struct tm_allocator_i
{
   struct tm_allocator_o *inst;
   void *(*malloc)(struct tm_allocator_o *inst, uint64_t size);
   void (*free)(struct tm_allocator_o *inst, void *pointer);
};

struct tm_object_system_i
{
   struct tm_object_system_o *inst;
   uint64_t (*create_object_of_type)(struct tm_object_system_o *inst, uint64_t type);
   struct tm_object_o *(*get_object)(struct tm_object_system_o *inst, uint64_t object_id);
   float (*get_float)(struct tm_object_system_o *inst, struct tm_object_o *object, uint64_t property); 
   void (*set_float)(struct tm_object_system_o *inst, struct tm_object_o *object, uint64_t property, float value);
};

struct tm_file_system_i
{
   struct tm_file_system_o *inst;
   struct tm_file_i *(*open)(struct tm_file_system_o *inst, const char *filename);
   void (*close)(struct tm_file_system_o *inst, struct tm_file_i *file);
   uint64_t (*size)(struct tm_file_system_o *inst, struct tm_file_t *file);
   uint64_t (*seek)(struct tm_file_system_o *inst, struct tm_file_t *file, uint64_t position);
   uint64_t (*tell)(struct tm_file_system_o *inst, struct tm_file_t *file);
   uint64_t (*read)(struct tm_file_system_o *inst, struct tm_file_t *file, uint64_t size, void *dst);
   uint64_t (*write)(struct tm_file_system_o *inst, struct tm_file_t *file, uint64_t size, const void *dst);
};

struct tm_render_system_i
{
   struct tm_render_system_o *inst;

   struct tm_render_framebuffer_o *(*create_framebuffer)(struct tm_render_system_o *inst,
      struct tm_render_framebuffer_desc_t *desc);
   void (*destroy_framebuffer)(struct tm_render_system_o *inst, struct tm_render_framebuffer_o *framebuffer);

   struct tm_render_program_o *(*create_program)(struct tm_render_system_o *inst, 
      struct tm_render_program_desc_t *desc);
   void (*destroy_program)(struct tm_render_system_o *inst, struct tm_render_program_o *program);

   struct tm_render_pipeline_o *(*create_pipeline)(struct tm_render_system_o *inst,
      struct tm_render_framebuffer_o *framebuffer,
      uint32_t primitive_topology,
      struct tm_render_program_o *program,
      struct tm_render_attribute_desc_t *attribute_desc,
      struct tm_render_blend_desc_t *blend_desc,
      struct tm_render_depth_stencil_desc_t *depth_stencil_desc,
      struct tm_render_rasterizer_desc_t *rasterizer_desc);
   void (*destroy_pipeline)(struct tm_render_system_o *inst, struct tm_render_pipeline_o *pipeline);

   struct tm_render_sampler_o *(*create_sampler)(struct tm_render_system_o *inst,
      struct tm_render_sampler_desc_t *desc);
   void (*destroy_sampler)(struct tm_render_system_o *inst, struct tm_render_sampler_o *sampler);

   struct tm_render_image_o *(*create_image)(struct tm_render_system_o *inst,
      struct tm_render_image_desc_t *desc,
      struct tm_render_image_data_t *data);
   void (*destroy_image)(struct tm_render_system_o *inst, struct tm_render_image_o *image);

   struct tm_render_buffer_o *(*create_buffer)(struct tm_render_system_o *inst,
      struct tm_render_buffer_desc_t *desc,
      struct tm_render_buffer_data_t *data);
   void (*destroy_buffer)(struct tm_render_system_o *inst, struct tm_render_buffer_o *buffer);
};

struct tm_render_framebuffer_desc_t {}; // formats, attached images, ...
struct tm_render_program_desc_t {}; // shader sources
struct tm_render_attribute_desc_t {}; // input layout/vertex format
struct tm_render_blend_desc_t {}; // ...
struct tm_render_depth_stencil_desc_t {}; // ..
struct tm_render_rasterizer_desc_t {}; // ...
struct tm_render_sampler_desc_t {}; // filter, addresses
struct tm_render_image_desc_t {}; // width, height, depth, levels, format
struct tm_render_image_data_t {}; // sizes, offsets/strides, pointers
struct tm_render_buffer_desc_t {}; // type, size. types: vertex, index, constant (opengl: ubo)
struct tm_render_buffer_data_t {}; // sizes, offsets/strides, pointers

struct tm_render_command_buffer_i
{
   struct tm_render_command_buffer_o *inst;
   void (*begin)(struct tm_render_command_buffer_o *inst);
   void (*finalize)(struct tm_render_command_buffer_o *inst);
   
   void (*update_image)(struct tm_render_command_buffer_o *inst, 
      struct tm_render_image_o *image,
      struct tm_render_image_desc_t *desc,
      struct tm_render_image_data_t *data);
   void (*update_buffer)(struct tm_render_command_buffer_o *inst, 
      struct tm_render_buffer_o *buffer,
      struct tm_render_buffer_desc_t *desc,
      struct tm_render_buffer_data_t *data);

   void (*clear_framebuffer)(struct tm_render_command_buffer_o *inst);

   void (*set_pipeline)(struct tm_render_command_buffer_o *inst, struct tm_render_pipeline_o *pipeline);
   void (*set_viewport)(struct tm_render_command_buffer_o *inst, struct tm_render_viewport_t *viewport);
   void (*set_buffer)(struct tm_render_command_buffer_o *inst, struct tm_render_buffer_o *buffer);
   void (*set_sampler)(struct tm_render_command_buffer_o *inst, struct tm_render_sampler_o *sampler);
   void (*set_image)(struct tm_render_command_buffer_o *inst, struct tm_render_image_o *image);
   void (*draw)(struct tm_render_command_buffer_o *inst, uint32_t start, uint32_t count);
   //void (*draw_indexed)(struct tm_render_command_buffer_o *inst, uint32_t start, uint32_t count);
};

struct tm_render_viewport_t
{
   int32_t x, y;
   uint32_t width;
   uint32_t height;
   float z_near;
   float z_far;
};

struct tm_render_command_t
{
   uint64_t sort_key;
   uint32_t type;
   void *data;
};

struct tm_render_data_block_t
{
   uint64_t size;
   uint8_t *base;
   uint8_t *at;
};

struct tm_audio_system_i
{
   struct tm_audio_system_o *inst;
   struct tm_audio_buffer_o *(*create_buffer)(struct tm_audio_system_o *inst, 
      struct tm_audio_desc_t *desc, struct tm_audio_data_t *data);
   void (*destroy_buffer)(struct tm_audio_system_o *inst, struct tm_audio_buffer_o *buffer);
   struct tm_audio_stream_o *(*create_stream)(struct tm_audio_system_o *inst, 
      struct tm_audio_desc_t *desc, struct tm_audio_data_t *data);
   void (*destroy_stream)(struct tm_audio_system_o *inst, struct tm_audio_stream_o *stream);
};

struct tm_audio_desc_t
{
   uint32_t rate;
   uint32_t channels;
   uint32_t length;
};

struct tm_audio_data_t
{
   void *source;
};

struct tm_audio_command_buffer_i
{
   struct tm_audio_command_buffer_o *inst;
   void (*begin)(struct tm_audio_command_buffer_o *inst);
   void (*finalize)(struct tm_audio_command_buffer_o *inst);
   void (*set_position)(struct tm_audio_command_buffer_o *inst, float x, float y, float z);
   void (*play_buffer)(struct tm_audio_command_buffer_o *inst, 
      struct tm_audio_buffer_o *buffer, 
      struct tm_audio_playback_t *playback);
   void (*play_stream)(struct tm_audio_command_buffer_o *inst, 
      struct tm_audio_stream_o *stream, 
      struct tm_audio_playback_t *playback);
   void (*stop_stream)(struct tm_audio_command_buffer_o *inst, 
      struct tm_audio_stream_o *stream, bool rewind);
};

struct tm_audio_playback_t
{
   float volume;
   float pan;
   float pitch;
};

#ifdef __cplusplus
}
#endif
#endif