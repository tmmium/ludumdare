// main.cc

#ifdef __cplusplus
extern "C" {
#endif

// types
typedef struct 
{
   float r;
   float g;
   float b;
   float a;
} L2D_Color;

typedef struct 
{
   int x, y;
   int width;
   int height;
} L2D_Rectangle;

typedef enum 
{
   TEXTURE_FORMAT_INVALID,
   TEXTURE_FORMAT_RGB8,
   TEXTURE_FORMAT_RGBA8,
} L2D_TextureFormat;

typedef struct  
{ 
   unsigned int id;
   int format; // L2D_TextureFormat
   int width;
   int height;
} L2D_Texture;

typedef enum
{
   SOUND_FORMAT_INVALID,
   SOUND_FORMAT_MONO_16I,
   SOUND_FORMAT_STEREO_16I,
} L2D_SoundFormat;

typedef struct  
{ 
   unsigned int id;
   int format; // L2D_SoundFormat
   int sample_rate;
   int sample_count;
   void *platform;
} L2D_Sound;

// input api
long long L2D_GetTicks();
int  L2D_InputKeyDown(int keycode);
int  L2D_InputMouseButton(int index);
void L2D_InputMousePosition(int *x, int *y);

// render api
void L2D_RenderCreateTextureFromFile(L2D_Texture *texture, int filtered /*0|1*/, 
   const char *filename);
void L2D_RenderCreateTexture(L2D_Texture *texture, int filtered /*0|1*/, 
   L2D_TextureFormat format, int width, int height, const void *data);
void L2D_RenderDestroyTexture(L2D_Texture *texture);
void L2D_RenderUpdateTexture(const L2D_Texture *texture, const void *data);
void L2D_RenderSetTextureFilter(const L2D_Texture *texture, int filtered /*0|1*/);
void L2D_RenderViewport(int x, int y, int width, int height);
void L2D_RenderClear(const L2D_Color *color);
void L2D_RenderDraw(const L2D_Texture *texture, const L2D_Rectangle *src, 
   const L2D_Rectangle *dst, const L2D_Color *color);

// audio api
void L2D_AudioCreateSoundFromFile(L2D_Sound *sound, const char *filename);
void L2D_AudioCreateSound(L2D_Sound *sound, int format, int sample_rate, 
   int sample_count, const void *data);
void L2D_AudioDestroySound(L2D_Sound *sound);
void L2D_AudioPlay(const L2D_Sound *sound, float volume /*0-1*/, 
   int play_count /*1-INT_MAX,0:infinite*/);
void L2D_AudioPlayMusic(const L2D_Sound *sound, float volume /*0-1*/);
void L2D_AudioStopMusic(const L2D_Sound *sound, int rewind);

#ifdef __cplusplus
}
#endif

// platform
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "opengl32.lib")

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <gl/GL.h>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#include <stb_image.h>

#include "audio.c"

static LRESULT CALLBACK WinProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam)
{
   switch (message)
   {
   case WM_INPUT:
   {
      static BYTE buf[sizeof(RAWINPUT)] = {0};
      UINT dwSize = sizeof(buf);
      GetRawInputData((HRAWINPUT)lParam, RID_INPUT, buf, &dwSize, sizeof(RAWINPUTHEADER));
      RAWINPUT *raw = (RAWINPUT *)buf;
      if (raw->header.dwType == RIM_TYPEMOUSE)
      {
         RAWMOUSE mouse = raw->data.mouse;
         /*global_mouse_movement.x += mouse.lLastX;
         global_mouse_movement.y += mouse.lLastY;
         if ((mouse.usButtonFlags & RI_MOUSE_LEFT_BUTTON_DOWN) != 0)
            input_state->buttons[BUTTON_LEFT] = 1;
         if ((mouse.usButtonFlags & RI_MOUSE_LEFT_BUTTON_UP) != 0)
            input_state->buttons[BUTTON_LEFT] = 0;
         if ((mouse.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_DOWN) != 0)
            input_state->buttons[BUTTON_RIGHT] = 1;
         if ((mouse.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_UP) != 0)
            input_state->buttons[BUTTON_RIGHT] = 0;*/
      }
      else if (raw->header.dwSize == RIM_TYPEKEYBOARD)
      {
         RAWKEYBOARD keyboard = raw->data.keyboard;
      }
   }
   break;
   case WM_CLOSE:
      PostQuitMessage(0);
      break;
   default:
      return DefWindowProcA(window, message, wParam, lParam);
   }
   return 0;
}

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
   const char *title = "ludumdare";
   const int width = 1280, height = 720;

   WNDCLASSA wc = {0};
   wc.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW,
   wc.lpfnWndProc = WinProc;
   wc.hInstance = hInstance; 
   wc.lpszClassName = "ludumdareClassName";
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = CreateSolidBrush(0x00000000);
   wc.hIcon = LoadIcon(wc.hInstance, MAKEINTRESOURCE(101));
   if (!RegisterClassA(&wc))
      return 0;

   DWORD ws = (WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU);
   RECT wr = {0, 0, width, height};
   if (!AdjustWindowRect(&wr, ws, 0))
      return 0;

   HWND window = CreateWindowA(wc.lpszClassName,
                               title, ws,
                               CW_USEDEFAULT, CW_USEDEFAULT,
                               wr.right - wr.left,
                               wr.bottom - wr.top,
                               0, 0,
                               wc.hInstance,
                               0);
   if (!window)
      return 0;
   
   HDC device_context_handle = GetDC(window);

   // opengl
   PIXELFORMATDESCRIPTOR pfd = {sizeof(pfd)};
   pfd.nVersion = 1;
   pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
   pfd.iPixelType = PFD_TYPE_RGBA;
   pfd.cColorBits = 32;
   pfd.cDepthBits = 24;
   pfd.cStencilBits = 8;
   pfd.iLayerType = PFD_MAIN_PLANE;

   int pixel_format_index = ChoosePixelFormat(device_context_handle, &pfd);
   if (!SetPixelFormat(device_context_handle, pixel_format_index, &pfd))
      return 0;

   HGLRC render_context_handle = wglCreateContext(device_context_handle);
   if (!wglMakeCurrent(device_context_handle, render_context_handle))
      return 0;

   typedef BOOL WINAPI wglSwapIntervalEXT_t(int interval);
   wglSwapIntervalEXT_t *wglSwapIntervalEXT = 
      (wglSwapIntervalEXT_t *)wglGetProcAddress("wglSwapIntervalEXT");
   if (wglSwapIntervalEXT)
      wglSwapIntervalEXT(1);

   // opengl default states
   glMatrixMode(GL_TEXTURE);
   glLoadIdentity();
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glDisable(GL_DEPTH);
   glEnable(GL_CULL_FACE);
   glCullFace(GL_BACK);
   glFrontFace(GL_CW);
   glEnable(GL_TEXTURE_2D);
   glEnableClientState(GL_VERTEX_ARRAY);

   ShowWindow(window, nCmdShow);

   audio_device_t *audio_device = audio_device_create(0);
#if 0
   // dsound
   HRESULT hr = DS_OK;
   IDirectSound *ds = 0;
   IDirectSoundBuffer *primary = 0;
   
   hr = DirectSoundCreate(0, &ds, 0);
   if (hr != DS_OK) { return 0; }

   hr = ds->SetCooperativeLevel(GetForegroundWindow(), DSSCL_PRIORITY);
   if (hr != DS_OK) { ds->Release(); return 0; }

   DSBUFFERDESC desc = {};
   desc.dwSize = sizeof(DSBUFFERDESC);
   desc.dwFlags = DSBCAPS_PRIMARYBUFFER;

   hr = ds->CreateSoundBuffer(&desc, &primary, 0);
   if (hr != DS_OK) { ds->Release(); return 0; }

   WAVEFORMATEX format = {};
   format.cbSize = sizeof(WAVEFORMATEX);
   format.wFormatTag = WAVE_FORMAT_PCM;
   format.nChannels = 2;
   format.nSamplesPerSec = 44100;
   format.wBitsPerSample = sizeof(short) * 8;
   format.nBlockAlign = (format.nChannels * format.wBitsPerSample) / 8;
   format.nAvgBytesPerSec = (format.nSamplesPerSec * format.nBlockAlign);

   hr = primary->SetFormat(&format);
   if (hr != DS_OK) { primary->Release(); ds->Release(); return 0; }
#endif

   // raw input
   RAWINPUTDEVICE rid[2] = {0};
   rid[0].usUsagePage = 0x01;
   rid[0].usUsage = 0x02; // mouse
   rid[0].dwFlags = 0;
   rid[0].hwndTarget = window;
   rid[1].usUsagePage = 0x01;
   rid[1].usUsage = 0x06; // keyboard
   rid[1].dwFlags = 0;
   rid[1].hwndTarget = window;
   BOOL success = RegisterRawInputDevices(rid, 2, sizeof(rid[0]));

   bool running = true;
   L2D_Texture texture = {};
   L2D_RenderCreateTextureFromFile(&texture, 0, "assets/5x3font.png");

   while (running)
   {
      MSG msg = {0};
      while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE))
      {
         if (msg.message == WM_QUIT)
            return 0;
         if (msg.message == WM_KEYUP && msg.wParam == VK_SPACE)
         {
            //L2D_AudioPlay(&sound, 1.0f, 1, 0);
         }

         TranslateMessage(&msg);
         DispatchMessage(&msg);
      }

      long long start_ticks = L2D_GetTicks();

      L2D_Color clear_color = { 0.1f, 0.2f, 0.2f, 1.0f };
      L2D_Rectangle src = { 0, 0, 64, 64 };
      L2D_Rectangle dst = { 0, 0, 512, 512 };

      L2D_RenderClear(&clear_color);
      L2D_RenderViewport(0, 0, width, height);
      L2D_RenderDraw(&texture, &src, &dst, 0);

      long long end_ticks = L2D_GetTicks();
      long long delta_ticks = end_ticks - start_ticks;
      
      SwapBuffers(device_context_handle);

      char title_ex[128];
      sprintf_s(title_ex, 128, "%s [%llums]", title, delta_ticks);
      SetWindowTextA(window, title_ex);
   }

   return 0;
}

// externals
//#define AUDIO_IMPLEMENTATION
//#include "audio.c"

// input api
long long L2D_GetTicks()
{
   static long long freq = 0, start = 0;
   if (!start)
   {
      QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
      QueryPerformanceCounter((LARGE_INTEGER *)&start);
      freq /= 1000;
   }

   long long now = 0;
   QueryPerformanceCounter((LARGE_INTEGER *)&now);
   long long diff = now - start;

   return (long long)(diff / freq);
}

int  L2D_InputKeyDown(int keycode)
{
   return 0;
}

int  L2D_InputMouseButton(int index)
{
   return 0;
}

void L2D_InputMousePosition(int *x, int *y)
{

}

// render api
void L2D_RenderCreateTextureFromFile(L2D_Texture *texture, int filtered /*0|1*/, 
   const char *filename)
{
   if (!texture) 
      return;
   
   int width = 0, height = 0, unused = 0;
   stbi_uc *data = stbi_load(filename, &width, &height, &unused, STBI_rgb_alpha);
   L2D_RenderCreateTexture(texture, filtered, TEXTURE_FORMAT_RGBA8, width, height, data);
   stbi_image_free(data);
}

static const GLenum gl_texture_formats[] = { 0, GL_RGB, GL_RGBA };
static const GLenum gl_internal_formats[] = { 0, GL_RGB8, GL_RGBA8 };

void L2D_RenderCreateTexture(L2D_Texture *texture, int filtered /*0|1*/, 
   L2D_TextureFormat format, int width, int height, const void *data)
{
   GLuint id = 0;
   glGenTextures(1, &id);
   glBindTexture(GL_TEXTURE_2D, id);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filtered ? GL_LINEAR : GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filtered ? GL_LINEAR : GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexImage2D(GL_TEXTURE_2D, 0, gl_texture_formats[format], 
      width, height, 0, gl_texture_formats[format], GL_UNSIGNED_BYTE, data);
   glBindTexture(GL_TEXTURE_2D, 0);

   texture->id = id;
   texture->format = format;
   texture->width = width;
   texture->height = height;
}

void L2D_RenderDestroyTexture(L2D_Texture *texture)
{
   GLuint id = texture->id;
   glDeleteTextures(1, &id);

   texture->id = 0;
   texture->format = 0; // TEXTURE_FORMAT_INVALID
   texture->width = 0;
   texture->height = 0;
}

void L2D_RenderUpdateTexture(const L2D_Texture *texture, const void *data)
{
   if (!texture)
      return;

   GLuint id = texture->id;
   GLint width = texture->width;
   GLint height = texture->height;
   GLenum format = gl_texture_formats[texture->format];

   glBindTexture(GL_TEXTURE_2D, id);
   glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
   glBindTexture(GL_TEXTURE_2D, 0);
}

void L2D_RenderSetTextureFilter(const L2D_Texture *texture, int filtered /*0|1*/)
{
   if (!texture)
      return;

   GLuint id = texture->id;

   glBindTexture(GL_TEXTURE_2D, id);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filtered ? GL_LINEAR : GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filtered ? GL_LINEAR : GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glBindTexture(GL_TEXTURE_2D, 0);
}

void L2D_RenderViewport(int x, int y, int width, int height)
{
   glViewport(x, y, width, height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0, width, height, 0, 0, 1);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void L2D_RenderClear(const L2D_Color *color)
{
   L2D_Color cc = { 0.0f, 0.0f, 0.0f, 1.0f };
   if (color) cc = *color;

   glClearColor(cc.r, cc.g, cc.b, cc.a);
   glClear(GL_COLOR_BUFFER_BIT);
}

static void
L2D__SetTexCoordPointerState(int state)
{
   if (state)
      glEnableClientState(GL_TEXTURE_COORD_ARRAY);
   else 
      glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}

struct Vertex
{
   float x, y;
   float u, v;
};

void L2D_RenderDraw(const L2D_Texture *texture, const L2D_Rectangle *src, 
   const L2D_Rectangle *dst, const L2D_Color *color)
{

   GLfloat white[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
   const GLfloat *quad_color = color ? (const GLfloat *)color : white;

   const float x0 = (float)dst->x;
   const float y0 = (float)dst->y;
   const float x1 = (float)(dst->x + dst->width);
   const float y1 = (float)(dst->y + dst->height);

   const float inv_width = texture ? 1.0f / (float)texture->width : 1.0f;
   const float inv_height = texture ? 1.0f / (float)texture->height : 1.0f;
   const float u0 = src->x * inv_width;
   const float v0 = src->y * inv_width;
   const float u1 = (src->x + src->width) * inv_width;
   const float v1 = (src->y + src->height) * inv_width;

   Vertex vertices[4] = {};
   vertices[0] = { x0, y0, u0, v0};
   vertices[1] = { x1, y0, u1, v0};
   vertices[2] = { x1, y1, u1, v1};
   vertices[3] = { x0, y1, u0, v1};

   const GLfloat *vertex_pointer = (const GLfloat *)vertices;
   const GLfloat *texcoord_pointer = (const GLfloat *)((char *)vertices + offsetof(Vertex, u));

   //glColor4fv(quad_color);
   glBindTexture(GL_TEXTURE_2D, texture ? texture->id : 0);
   glVertexPointer(2, GL_FLOAT, sizeof(Vertex), vertex_pointer);
   glTexCoordPointer(2, GL_FLOAT, sizeof(Vertex), texcoord_pointer);
   L2D__SetTexCoordPointerState(texture ? 1 : 0);
   glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
}

// audio api
void L2D_AudioCreateSoundFromFile(L2D_Sound *sound, const char *filename)
{
   
}

void L2D_AudioCreateSound(L2D_Sound *sound, int format, int sample_rate, 
   int sample_count, const void *data)
{
   sound->id = 0;
   sound->format = format;
   sound->sample_rate = sample_rate;
   sound->sample_count = sample_count;
   sound->platform = 0;
}

void L2D_AudioDestroySound(L2D_Sound *sound)
{
}

void L2D_AudioPlay(const L2D_Sound *sound, float volume /*0-1*/, int play_count)
{
}

void L2D_AudioPlayMusic(const L2D_Sound *sound, float volume /*0-1*/)
{
}

void L2D_AudioStopMusic(const L2D_Sound *sound, int rewind)
{
}

//#define AUDIO_IMPLEMENTATION
//#include "audio.c"

//#define OPENAL_LITE_IMPLEMENTATION
//#include "openal_lite.h"
