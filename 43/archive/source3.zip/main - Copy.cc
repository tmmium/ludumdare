// main.cc

#include "game_api.h"

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")

#define _CRT_SECURE_NO_WARNINGS

#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <math.h>

#include <windows.h>
#include <windowsx.h>

#include <gl/gl.h>
#include <dsound.h>

static IDirectSound *global_sound_device = 0;
static IDirectSoundBuffer *global_primary_buffer = 0;
static uint8_t global_keyboard_state[256] = {};
static uint8_t global_button_state[8] = {};
static v2i global_mouse_movement = {};
static v2i global_mouse_position = {};

struct WinInputState
{
   uint8_t keys[256];
   uint8_t buttons[8];
   v2i position;
   v2i movement;
};

static WinInputState *global_input_state = 0;

static void *
WinAlloc(int size)
{
   return _aligned_malloc(size, 4);
}

static void
WinFree(void *pointer)
{
   _aligned_free(pointer);
}

static loaded_file
WinLoad(const char *filename)
{
   loaded_file result = {};

   HANDLE file = CreateFileA(filename, GENERIC_READ, FILE_SHARE_READ,
                             NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
   if (file != INVALID_HANDLE_VALUE)
   {
      uint32_t size = GetFileSize(file, NULL);
      uint8_t *data = (uint8_t *)WinAlloc(size);
      memset(data, 0, size);
      ReadFile(file, data, size, NULL, NULL);
      CloseHandle(file);

      result.size = size;
      result.data = data;
   }
   
   return result;
}

static uint32_t
WinGetTicks()
{
   static __int64 f = 0, s = 0;
   if (!s)
   {
      QueryPerformanceFrequency((LARGE_INTEGER *)&f);
      QueryPerformanceCounter((LARGE_INTEGER *)&s);
      f /= 1000;
   }

   __int64 c = 0;
   QueryPerformanceCounter((LARGE_INTEGER *)&c);
   __int64 d = c - s;

   return (uint32_t)(d / f);
}


static int
WinKeyDown(int index)
{
   static const int vktable[KEYCODE_COUNT] =
   {
      VK_CANCEL,
      VK_BACK,
      VK_TAB,
      VK_CLEAR,
      VK_RETURN,
      VK_SHIFT,
      VK_CONTROL,
      VK_MENU,
      VK_PAUSE,
      VK_CAPITAL,
      VK_FINAL,
      VK_ESCAPE,
      VK_CONVERT,
      VK_NONCONVERT,
      VK_ACCEPT,
      VK_MODECHANGE,
      VK_SPACE,
      VK_PRIOR,
      VK_NEXT,
      VK_END,
      VK_HOME,
      VK_LEFT,
      VK_UP,
      VK_RIGHT,
      VK_DOWN,
      VK_SELECT,
      VK_PRINT,
      VK_SNAPSHOT,
      VK_INSERT,
      VK_DELETE,
      VK_HELP,
      '0',
      '1',
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9',
      'A',
      'B',
      'C',
      'D',
      'E',
      'F',
      'G',
      'H',
      'I',
      'J',
      'K',
      'L',
      'M',
      'N',
      'O',
      'P',
      'Q',
      'R',
      'S',
      'T',
      'U',
      'V',
      'W',
      'X',
      'Y',
      'Z',
      VK_LWIN,
      VK_RWIN,
      VK_APPS,
      VK_SLEEP,
      VK_NUMPAD0,
      VK_NUMPAD1,
      VK_NUMPAD2,
      VK_NUMPAD3,
      VK_NUMPAD4,
      VK_NUMPAD5,
      VK_NUMPAD6,
      VK_NUMPAD7,
      VK_NUMPAD8,
      VK_NUMPAD9,
      VK_MULTIPLY,
      VK_ADD,
      VK_SEPARATOR,
      VK_SUBTRACT,
      VK_DECIMAL,
      VK_DIVIDE,
      VK_F1,
      VK_F2,
      VK_F3,
      VK_F4,
      VK_F5,
      VK_F6,
      VK_F7,
      VK_F8,
      VK_F9,
      VK_F10,
      VK_F11,
      VK_F12,
      VK_F13,
      VK_F14,
      VK_F15,
      VK_F16,
      VK_F17,
      VK_F18,
      VK_F19,
      VK_F20,
      VK_F21,
      VK_F22,
      VK_F23,
      VK_F24,
      VK_NUMLOCK,
      VK_SCROLL,
      VK_LSHIFT,
      VK_RSHIFT,
      VK_LCONTROL,
      VK_RCONTROL,
      VK_LMENU,
      VK_RMENU,
      VK_BROWSER_BACK,
      VK_BROWSER_FORWARD,
      VK_BROWSER_REFRESH,
      VK_BROWSER_STOP,
      VK_BROWSER_SEARCH,
      VK_BROWSER_FAVORITES,
      VK_BROWSER_HOME,
      VK_VOLUME_MUTE,
      VK_VOLUME_DOWN,
      VK_VOLUME_UP,
      VK_MEDIA_NEXT_TRACK,
      VK_MEDIA_PREV_TRACK,
      VK_MEDIA_STOP,
      VK_MEDIA_PLAY_PAUSE,
      VK_LAUNCH_MAIL,
      VK_LAUNCH_MEDIA_SELECT,
      VK_LAUNCH_APP1,
      VK_LAUNCH_APP2,
      VK_OEM_1,
      VK_OEM_PLUS,
      VK_OEM_COMMA,
      VK_OEM_MINUS,
      VK_OEM_PERIOD,
      VK_OEM_2,
      VK_OEM_3,
      VK_OEM_4,
      VK_OEM_5,
      VK_OEM_6,
      VK_OEM_7,
      VK_OEM_8,
      VK_OEM_102,
      VK_PROCESSKEY,
      VK_PACKET,
      VK_ATTN,
      VK_CRSEL,
      VK_EXSEL,
      VK_EREOF,
      VK_PLAY,
      VK_ZOOM,
      VK_NONAME,
      VK_PA1,
      VK_OEM_CLEAR, 
   };
   return global_input_state->keys[vktable[index]];
}

static int
WinButtonDown(mouse_button index)
{
   return global_input_state->buttons[(int)index];
}

static v2i
WinMousePosition()
{
   return global_input_state->position;
}

static v2i
WinMouseMovement()
{
   return global_input_state->movement;
}

static LRESULT CALLBACK WinProc(HWND window_handle, UINT message_id, WPARAM w_param, LPARAM l_param)
{
   WinInputState *input_state = (WinInputState *)GetWindowLongPtrA(window_handle, GWLP_USERDATA);
   if (!input_state) 
      return DefWindowProcA(window_handle, message_id, w_param, l_param);

   switch (message_id)
   {
   case WM_INPUT:
   {
      static BYTE buf[sizeof(RAWINPUT)] = {0};
      UINT dwSize = sizeof(buf);
      GetRawInputData((HRAWINPUT)l_param, RID_INPUT, buf, &dwSize, sizeof(RAWINPUTHEADER));
      RAWINPUT *raw = (RAWINPUT *)buf;
      if (raw->header.dwType == RIM_TYPEMOUSE)
      {
         RAWMOUSE mouse = raw->data.mouse;
         global_mouse_movement.x += mouse.lLastX;
         global_mouse_movement.y += mouse.lLastY;
         if ((mouse.usButtonFlags & RI_MOUSE_LEFT_BUTTON_DOWN) != 0)
            input_state->buttons[BUTTON_LEFT] = 1;
         if ((mouse.usButtonFlags & RI_MOUSE_LEFT_BUTTON_UP) != 0)
            input_state->buttons[BUTTON_LEFT] = 0;
         if ((mouse.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_DOWN) != 0)
            input_state->buttons[BUTTON_RIGHT] = 1;
         if ((mouse.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_UP) != 0)
            input_state->buttons[BUTTON_RIGHT] = 0;
      }
      else if (raw->header.dwSize == RIM_TYPEKEYBOARD)
      {
         RAWKEYBOARD keyboard = raw->data.keyboard;
      }
   }
   break;
   case WM_MOUSEMOVE:
   {
      input_state->position.x = GET_X_LPARAM(l_param);
      input_state->position.y = GET_Y_LPARAM(l_param);
   }
   break;
   case WM_KEYDOWN:
   case WM_KEYUP:
   {
      int vkey = w_param & 0xff;
      int down = message_id == WM_KEYDOWN ? 1 : 0;
      input_state->keys[vkey] = down;
   }
   break;
   case WM_CLOSE:
      PostQuitMessage(0);
      break;
   default:
      return DefWindowProcA(window_handle, message_id, w_param, l_param);
   }
   return 0;
}

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
   const char *title = "ludumdare";
   const int width = 1280, height = 720;

   WNDCLASSA wc = {0};
   wc.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW,
   wc.lpfnWndProc = WinProc;
   wc.hInstance = hInstance; //GetModuleHandle(NULL);
   wc.lpszClassName = "macadamiaClassName";
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = CreateSolidBrush(0x00000000);
   wc.hIcon = LoadIcon(wc.hInstance, MAKEINTRESOURCE(101));
   if (!RegisterClassA(&wc))
      return 0;

   DWORD ws = (WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU);
   RECT wr = {0, 0, width, height};
   if (!AdjustWindowRect(&wr, ws, 0))
      return 0;

   HWND window = CreateWindowA(wc.lpszClassName,
                               title, ws,
                               CW_USEDEFAULT, CW_USEDEFAULT,
                               wr.right - wr.left,
                               wr.bottom - wr.top,
                               0, 0,
                               wc.hInstance,
                               0);
   if (!window)
      return 0;

   RAWINPUTDEVICE rid[1] = {0};
   rid[0].usUsagePage = 0x01;
   rid[0].usUsage = 0x02;
   rid[0].dwFlags = RIDEV_INPUTSINK;
   rid[0].hwndTarget = window;
   RegisterRawInputDevices(rid, 1, sizeof(rid[0]));

   HDC device = GetDC(window);
   PIXELFORMATDESCRIPTOR pfd = {sizeof(PIXELFORMATDESCRIPTOR), 1,
                                PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA,
                                32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, PFD_MAIN_PLANE, 0, 0, 0, 0};
   SetPixelFormat(device, ChoosePixelFormat(device, &pfd), &pfd);
   if (!wglMakeCurrent(device, wglCreateContext(device)))
      return -1;

   typedef BOOL wglSwapIntervalEXT_t(int interval);
   wglSwapIntervalEXT_t *wglSwapIntervalEXT = (wglSwapIntervalEXT_t *)wglGetProcAddress("wglSwapIntervalEXT");
   if (wglSwapIntervalEXT)
      wglSwapIntervalEXT(1);

   glViewport(0, 0, width, height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0, width, height, 0, -1, 1);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glEnable(GL_DEPTH_TEST);
   glEnable(GL_TEXTURE_2D);
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glEnableClientState(GL_VERTEX_ARRAY);
   glEnableClientState(GL_TEXTURE_COORD_ARRAY);
   glClearDepth(1.0f);
   glClearColor(0.1f, 0.2f, 0.2f, 1.0f);

   HRESULT hr = S_OK;
   IDirectSound *dsound = NULL;
   hr = DirectSoundCreate(NULL, &dsound, NULL);
   if (FAILED(hr))
      return -2;

   hr = dsound->SetCooperativeLevel(window, DSSCL_PRIORITY);
   if (FAILED(hr))
      return -2;

   WAVEFORMATEX fmt = {0};
   fmt.cbSize = sizeof(WAVEFORMATEX);
   fmt.wFormatTag = WAVE_FORMAT_PCM;
   fmt.nChannels = 2;
   fmt.nSamplesPerSec = 44100;
   fmt.wBitsPerSample = 16;
   fmt.nBlockAlign = (fmt.nChannels * fmt.wBitsPerSample) / 8;
   fmt.nAvgBytesPerSec = fmt.nSamplesPerSec * fmt.nBlockAlign;

   DSBUFFERDESC desc = {0};
   desc.dwSize = sizeof(DSBUFFERDESC);
   desc.dwFlags = DSBCAPS_PRIMARYBUFFER | DSBCAPS_CTRLVOLUME;
   IDirectSoundBuffer *primary = NULL;
   hr = dsound->CreateSoundBuffer(&desc, &primary, NULL);
   if (FAILED(hr))
      return -2;

   hr = primary->SetFormat(&fmt);
   if (FAILED(hr))
   {
      primary->Release();
      return -2;
   }

   global_sound_device = dsound;
   global_primary_buffer = primary;

   WinInputState input_state_ = {};
   WinInputState *input_state = &input_state_;
   global_input_state = input_state;
   SetWindowLongPtrA(window, GWLP_USERDATA, (LONG_PTR)input_state);

   const char *game_dll_name = "macadamia.dll";
   HMODULE game_dll = LoadLibraryA(game_dll_name);
   if (!game_dll)
      return -3;

   game_tick_callback *game_tick = (game_tick_callback *)GetProcAddress(game_dll, "game_tick");
   if (!game_tick)
      return -3;

   platform_api platform_ = {};
   platform_api *platform = &platform_;
   platform_.alloc = WinAlloc;
   platform_.free = WinFree;
   platform_.load = WinLoad;
   platform_.get_ticks = WinGetTicks;

   input_api input_ = {};
   input_api *input = &input_;
   input_.key_down = WinKeyDown;
   input_.button_down = WinButtonDown;
   input_.mouse_movement = WinMouseMovement;
   input_.mouse_position = WinMousePosition;

   ShowWindow(window, nCmdShow);

   bool running = true;
   while (running)
   {
      unsigned start_ticks = WinGetTicks();

      MSG msg = {0};
      while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE))
      {
         if (msg.message == WM_QUIT)
            return 0;

         TranslateMessage(&msg);
         DispatchMessage(&msg);
      }

      if (!game_tick(platform, input))
         return 0;

      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      SwapBuffers(device);

      unsigned end_ticks = WinGetTicks();
      unsigned delta_ticks = end_ticks - start_ticks;

      char title_ex[128];
      sprintf_s(title_ex, 128, "%s [%ums]", title, delta_ticks);
      SetWindowTextA(window, title_ex);
   }

   return 0;
}
