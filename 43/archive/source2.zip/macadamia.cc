// macadamia.cc

#include "game_api.h"

#ifdef __cplusplus
extern "C"
{
#endif

GAME_TICK_CALLBACK(game_tick)
{
   if (input->button_down(BUTTON_LEFT))
      return 0;
   return 1;
}

#ifdef __cplusplus
}
#endif
