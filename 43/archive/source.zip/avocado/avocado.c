// avocado.c

#define _CRT_SECURE_NO_WARNINGS
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "opengl32.lib")
#include <windows.h>
#include <windowsx.h>
#include <gl/gl.h>
#include <dsound.h>
#include <stdbool.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>

#include "avocado.h"
#include "avocado_keyboard.h"
#include "avocado_mouse.h"

typedef struct
{
   int x, y;
} v2i;

static const char *global_window_title = 0;
static HWND global_window_handle = 0;
static HDC global_window_device = 0;
static int global_window_width = 0;
static int global_window_height = 0;
static IDirectSound *global_sound_device = 0;
static IDirectSoundBuffer *global_primary_buffer = 0;
static v2i global_mouse_position = {0};
static v2i global_mouse_movement = {0};
static v2 global_mouse_wheel = {0};
static int global_mouse_buttons[MOUSE_BUTTON_COUNT] = {0};
static int global_keyboard_keys[256] = {0};

static void
WinSetMousePosition(int x, int y)
{
   global_mouse_position.x = x;
   global_mouse_position.y = y;
}

static void 
WinSetMouseMovement(int x, int y)
{
   global_mouse_movement.x += x;
   global_mouse_movement.y += y;
}

static void 
WinSetMouseButtonState(int index, int state)
{
   global_mouse_buttons[index] = state;
}

static void
WinSetMouseWheel(float y)
{
   global_mouse_wheel.y = y;
}

static LRESULT CALLBACK WinProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   switch (uMsg)
   {
   case WM_INPUT:
   {
      static BYTE buf[48] = {0};
      UINT dwSize = sizeof(buf);
      GetRawInputData((HRAWINPUT)lParam, RID_INPUT, buf, &dwSize, sizeof(RAWINPUTHEADER));
      RAWINPUT *raw = (RAWINPUT *)buf;
      if (raw->header.dwType == RIM_TYPEMOUSE)
      {
         RAWMOUSE mouse = raw->data.mouse;
         WinSetMouseMovement(mouse.lLastX, mouse.lLastY);
         if ((mouse.usButtonFlags & RI_MOUSE_LEFT_BUTTON_DOWN) != 0)
            WinSetMouseButtonState(BUTTON_LEFT, 1);
         if ((mouse.usButtonFlags & RI_MOUSE_LEFT_BUTTON_UP) != 0)
            WinSetMouseButtonState(BUTTON_LEFT, 0);
         if ((mouse.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_DOWN) != 0)
            WinSetMouseButtonState(BUTTON_MIDDLE, 1);
         if ((mouse.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_DOWN) != 0)
            WinSetMouseButtonState(BUTTON_MIDDLE, 0);
         if ((mouse.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_DOWN) != 0)
            WinSetMouseButtonState(BUTTON_RIGHT, 1);
         if ((mouse.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_UP) != 0)
            WinSetMouseButtonState(BUTTON_RIGHT, 0);
      }
   }
   break;
   case WM_MOUSEMOVE:
   {
      WinSetMousePosition(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
   }
   break;
   case WM_MOUSEWHEEL:
   {
      WinSetMouseWheel((float)GET_WHEEL_DELTA_WPARAM(wParam) / (float)WHEEL_DELTA);
   }
   break;
#if 1
   case WM_KEYDOWN:
   case WM_KEYUP:
   {
      int index = wParam;
      int state = uMsg == WM_KEYDOWN ? 1 : 0;
      if (index <= 0xff)
      {
         if (state && !global_keyboard_keys[index])
            global_keyboard_keys[index] = state;
         else// if (!state && global_keyboard_keys[index])
            global_keyboard_keys[index] = state;
      }
   }
   break;
#endif
   case WM_GETMINMAXINFO:
   {
      RECT cr = {0};
      cr.right = 320;
      cr.bottom = 180;
      AdjustWindowRect(&cr, WS_OVERLAPPEDWINDOW, FALSE);

      MINMAXINFO *mmi = (MINMAXINFO *)lParam;
      mmi->ptMinTrackSize.x = cr.right - cr.left;
      mmi->ptMinTrackSize.y = cr.bottom - cr.top;
   }
   break;
   case WM_CLOSE:
   {
      PostQuitMessage(0);
   }
   break;
   default:
   {
      return DefWindowProcA(hWnd, uMsg, wParam, lParam);
   }
   break;
   }
   return 0;
}

int avocado_init(int width, int height, const char *title)
{
   //freopen("debug.txt", "w", stdout);

   WNDCLASSA wc = {0};
   wc.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW,
   wc.lpfnWndProc = WinProc;
   wc.hInstance = GetModuleHandle(NULL);
   wc.lpszClassName = "carrotClassName";
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = CreateSolidBrush(0x00000000);
   wc.hIcon = LoadIcon(wc.hInstance, MAKEINTRESOURCE(101));
   if (!RegisterClassA(&wc))
      return 0;

   global_window_width = width;
   global_window_height = height;
   DWORD ws = (WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU);
   RECT wr = {0};
   wr.right = width;
   wr.bottom = height;
   if (!AdjustWindowRect(&wr, ws, 0))
      return 0;

   HWND window = CreateWindowA(wc.lpszClassName,
                              title, ws,
                              CW_USEDEFAULT, CW_USEDEFAULT,
                              wr.right - wr.left,
                              wr.bottom - wr.top,
                              0, 0,
                              wc.hInstance,
                              0);
   if (!window)
      return 0;

   RAWINPUTDEVICE rid[1] = {0};
   rid[0].usUsagePage = 0x01;
   rid[0].usUsage = 0x02;
   rid[0].dwFlags = RIDEV_INPUTSINK;
   rid[0].hwndTarget = window;
   RegisterRawInputDevices(rid, 1, sizeof(rid[0]));

   HDC device = GetDC(window);
   PIXELFORMATDESCRIPTOR pfd = {sizeof(PIXELFORMATDESCRIPTOR), 1,
                                PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA,
                                32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, PFD_MAIN_PLANE, 0, 0, 0, 0};
   SetPixelFormat(device, ChoosePixelFormat(device, &pfd), &pfd);
   if (!wglMakeCurrent(device, wglCreateContext(device)))
      return 0;

   typedef BOOL wglSwapIntervalEXT_t(int interval);
   wglSwapIntervalEXT_t *wglSwapIntervalEXT = (wglSwapIntervalEXT_t *)wglGetProcAddress("wglSwapIntervalEXT");
   if (wglSwapIntervalEXT)
      wglSwapIntervalEXT(1);

   glViewport(0, 0, width, height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0, width, height, 0, -1, 1);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glEnable(GL_DEPTH_TEST);
   glEnable(GL_TEXTURE_2D);
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glEnableClientState(GL_VERTEX_ARRAY);
   glEnableClientState(GL_TEXTURE_COORD_ARRAY);
   glClearDepth(1.0f);
   glClearColor(0.1f, 0.2f, 0.2f, 1.0f);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   global_window_handle = window;
   global_window_title = title;
   global_window_handle = window;
   global_window_device = device;
   //global_sound_device = dsound;
   //global_primary_buffer = primary;

   ShowWindow(window, SW_SHOWNORMAL);

   return 1;
}

int avocado_process()
{
   SwapBuffers(global_window_device);
   //Sleep(15); // todo: remove this sleep

   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   static unsigned prev = 0;
   unsigned now = avocado_get_ticks();
   unsigned diff = now - prev;
   prev = now;
   char title[128];
   sprintf_s(title, 128, "%s [%ums]", global_window_title, diff);
   SetWindowTextA(global_window_handle, title);

   WinSetMouseWheel(0);

   MSG msg = {0};
   while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
   {
      if (msg.message == WM_QUIT)
      {
         return 0;
      }
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }

   return 1;
}

int avocado_get_ticks()
{
   static __int64 f = 0, s = 0;
   if (!s)
   {
      QueryPerformanceFrequency((LARGE_INTEGER *)&f);
      QueryPerformanceCounter((LARGE_INTEGER *)&s);
      f /= 1000;
   }
   __int64 c = 0;
   QueryPerformanceCounter((LARGE_INTEGER *)&c);
   __int64 d = c - s;
   return (int)(d / f);
}

int avocado_logf(const char *format, ...)
{
  va_list vl;
  va_start(vl, format);
  int result = vfprintf(stdout, format, vl);
  va_end(vl);
  return result;
}

int avocado_key_down(int index)
{
   if (index >= 0xff || index < 0)
      return 0;
   int vkey = global_keycode_lookup_table[index & 0xff];
   return global_keyboard_keys[vkey];
}

#pragma warning(push)
#pragma warning(disable:4204) // nonstandard extension used: non-constant aggregate initializer
v2 avocado_mouse_position()
{
   return (v2){global_mouse_position.x, global_mouse_position.y};
}
#pragma warning(pop)

int avocado_mouse_button(int index)
{
   if (index >= MOUSE_BUTTON_COUNT || index < 0)
      return 0;
   return global_mouse_buttons[index];
}
