// avocado_mouse.h

static int global_button_lookup_table[] =
{
   0,
   0,
   0,
   0,
   0,
   0,
};

static const char *global_button_name_table[] =
{
   "0",
   "0",
   "0",
   "0",
   "0",
   "0",
};
