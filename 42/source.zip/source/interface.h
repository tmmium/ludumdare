// interface.h

#include <stdint.h>

#define ASSERT(x)       if (!(x)) {*(int *)0=0;}
#define ARRAYSIZE(x)    (sizeof(x) / sizeof(x[0]))

typedef float f32;
typedef struct v2 { f32 x, y;       } v2;
typedef struct v3 { f32 x, y, z;    } v3;
typedef struct v4 { f32 x, y, z, w; } v4;
typedef struct m4 { v4 x, y, z, w;  } m4;

typedef struct
{
   int size;
   char *base;
   char *at;
} allocator_t;

void *qk_alloc(allocator_t *allocator, int size)
{
   ASSERT((allocator->at - allocator->base) < allocator->size);

   void *result = allocator->at;
   allocator->at += size;

   return result;
}

typedef struct 
{
   int x;
   int y;
   int buttons[2];
} input_t;

typedef struct 
{
   uint32_t color;
   struct 
   {
      uint32_t index : 10;
      uint32_t x_pos : 10;
      uint32_t y_pos : 10;
      uint32_t scale : 2;
   } u;
} drawcmd_t;

typedef struct 
{
   v4 clear_color;
   m4 projection;
   uint32_t capacity;
   drawcmd_t *base;
   drawcmd_t *at;
} render_commands_t;

void set_clear_color(render_commands_t *render_commands, v4 clear_color)
{
   render_commands->clear_color = clear_color;
}

void set_projection(render_commands_t *render_commands, m4 projection)
{
   render_commands->projection = projection;
}

void push_command(render_commands_t *render_commands, uint32_t index, 
                  uint32_t color, int x_pos, int y_pos, int scale)
{
   if (scale == 0)
      scale = 1;

   drawcmd_t command = {0};

   command.color = color;
   command.u.index = index;
   command.u.x_pos = x_pos;
   command.u.y_pos = y_pos;
   command.u.scale = scale - 1;

   *render_commands->at++ = command;
}

