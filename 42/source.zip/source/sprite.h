// sprite.h

typedef enum
{
   SPR_START = 92,

   // interaction
   SPR_HOVER,
   SPR_SELECTED,
   SPR_RESERVED,
   
   // 
   SPR_WATER0, SPR_WATER1, SPR_WATER2,
   SPR_GRASS0, SPR_GRASS1, SPR_GRASS2,

} sprite_type_t;
