// ludumdare42.c

// --  Running out of space  -- 

#include <stdio.h>  // vsnprintf
#include <stdarg.h> // va_list
#include <time.h>

#include "interface.h"
#include "math.h"
#include "text.h"
#include "debug.h"

#include "sprite.h"
#include "world.h"

static const int kScreenWidth  = 320;
static const int kScreenHeight = 180;

typedef struct env_t env_t;
static env_t *env;

struct env_t
{
   world_t world;

   v2 mouse;
   int buttons[2];
};

static void
mouse_scaled(input_t *input, v2 *mouse)
{
   mouse->x = input->x * 0.25f;
   mouse->y = input->y * 0.25f;
}

static void 
mouse_buttons(input_t *input, int *buttons)
{
   buttons[0] = input->buttons[0];
   buttons[1] = input->buttons[1];
}

static void 
mouse_post_frame(env_t *env, input_t *input)
{
   mouse_scaled(input, &env->mouse);
   mouse_buttons(input, env->buttons);
}

static int
button_down_once(env_t *env, int *buttons, int index)
{
   return buttons[index] && !env->buttons[index];
}

__declspec(dllexport) int 
game_update_and_render(allocator_t *allocator, input_t *input, render_commands_t *render_commands)
{
   v2 mouse = {0};
   int buttons[2] = {0};
   mouse_scaled(input, &mouse);
   mouse_buttons(input, buttons);

   if (!env)
   {
      initialize_random(0);

      env = (env_t *)qk_alloc(allocator, sizeof(env_t));
      world_init(&env->world, allocator);
   }

   set_clear_color(render_commands, (v4) { 0.1f, 0.2f, 0.2f, 1.0f });
   set_projection(render_commands, orthographic(kScreenWidth, kScreenHeight));

   debug_init(render_commands, kScreenWidth, kScreenHeight);
   debug_start();

   world_update(&env->world, mouse.x, mouse.y, input->buttons);
   draw_world(&env->world, render_commands);

   const char *text = "Running out of space";
   const int text_scale = 1; 
   draw_text_shadowed(render_commands, 
                      0xffffffff, 
                      0xff000000, 
                      220, 
                      2, 
                      text_scale, 
                      text);

   debug_text("%d,%d", (int)mouse.x, (int)mouse.y);
   if (button_down_once(env, buttons, 1))
      world_generate(&env->world);

   mouse_post_frame(env, input);

   return 1;
}
