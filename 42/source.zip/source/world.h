// world.h

static const int kMapWidth          = 27;
static const int kMapHeight         = 22;

static const int kTileSize          = 8;
static const int kTileOffset        = 1;
static const int kMapOffsetX        = 2;
static const int kMapOffsetY        = 2;
static const unsigned kTileColor    = 0xffffffff;

static const int kWaterSpriteTable[] = { SPR_WATER0, SPR_WATER1, SPR_WATER2, };
static const int kGrassSpriteTable[] = { SPR_GRASS0, SPR_GRASS1, SPR_GRASS2, };
static const int kTreeSpriteTable[]  = { 0 };

static const char *kTileBaseString[] = { "Water", "Grass", };
static const char *kTileFloraString[]= { "None", "Flower", "Tree", };

typedef enum
{
   TILE_BASE_WATER,
   TILE_BASE_GRASS, 
   TILE_BASE_COUNT,
} tile_base_t;


typedef enum 
{
   TILE_FLORA_NONE,
   TILE_FLORA_FLOWER,
   TILE_FLORA_TREE,
   TILE_FLORA_COUNT,
} tile_flora_t;

typedef struct
{
   tile_base_t base;
   int base_sprite_index;
   tile_flora_t flora;
   int flora_sprite_index;
} tile_t;

typedef struct 
{
   int hover_index;
   int selected_index;
   int width;
   int height;
   int tile_count;
   tile_t *tiles;

   int info_box_x;
   int info_box_y;
} world_t;

static void
world_generate(world_t *world)
{
   int tile_count = world->tile_count;
   tile_t *tile = world->tiles;
   for (int tile_index = 0; 
        tile_index < tile_count; 
        tile_index++)
   {
      int base_type = random() % TILE_BASE_COUNT;
      int base_sprite_index = -1;

      switch(base_type)
      {
         case TILE_BASE_WATER:
         {
            int index = random() % ARRAYSIZE(kWaterSpriteTable);
            base_sprite_index = kWaterSpriteTable[index];
         } break;
         case TILE_BASE_GRASS:
         {
            int index = random() % ARRAYSIZE(kGrassSpriteTable);
            base_sprite_index = kGrassSpriteTable[index];
         } break;
      }

      tile->base = base_type;
      tile->base_sprite_index = base_sprite_index;
      
      tile->flora = TILE_FLORA_NONE;
      tile->flora_sprite_index = -1;

      tile++;
   }

   world->hover_index = -1;
   world->selected_index = -1;
}

static void
world_init(world_t *world, allocator_t *allocator)
{
   int width = kMapWidth;
   int height = kMapHeight;
   int count = width * height;
   tile_t *tiles = (tile_t *)qk_alloc(allocator, sizeof(tile_t) * count);

   world->hover_index = -1;
   world->selected_index = -1;
   world->width = width;
   world->height = height;
   world->tile_count = count;
   world->tiles = tiles;
   world->info_box_x = 220;
   world->info_box_y = 22;
   world_generate(world);
}

static void
world_update(world_t *world, int x, int y, int *buttons)
{
   int width = world->width;
   int height = world->height;

   x -= kMapOffsetX;
   y -= kMapOffsetY; 

   x /= kTileSize;
   y /= kTileSize;

   world->hover_index = -1;

   int tile_index = y * width + x;
   int is_valid = (x >= 0 && x < width && y >= 0 && y < height) ? 1 : 0;

   if (is_valid)
   {
      world->hover_index = tile_index;

      int is_down = buttons[0];
      if (is_down && world->selected_index == -1)
      {
         world->selected_index = tile_index;
      }
      else if (is_down && world->selected_index != tile_index)
      {
         world->selected_index = tile_index;
      }
   }
}

static void 
draw_world(world_t *world, render_commands_t *render_commands)
{
   int width = world->width;
   int height = world->height;
   int hover_index = world->hover_index;
   int selected_index = world->selected_index;

   tile_t *tile = world->tiles;
   for (int yy = 0, index = 0; yy < height; yy++)
   {
      for (int xx = 0; xx < width; xx++)
      {
         int sprite_index = tile->base_sprite_index;
         tile++;

         push_command(render_commands, 
                      sprite_index, 
                      kTileColor, 
                      kMapOffsetX + xx * kTileSize,
                      kMapOffsetY + yy * kTileSize,
                      1);

         if (selected_index == index)
         {
            push_command(render_commands, 
                         SPR_SELECTED, 
                         kTileColor, 
                         kMapOffsetX + xx * kTileSize,
                         kMapOffsetY + yy * kTileSize,
                         1);
         }
         else if (hover_index == index)
         {
            push_command(render_commands, 
                         SPR_HOVER, 
                         kTileColor, 
                         kMapOffsetX + xx * kTileSize,
                         kMapOffsetY + yy * kTileSize,
                         1);
         }

         index++;
      }
   }

   // render selected info
   int info_box_x = world->info_box_x;
   int info_box_y = world->info_box_y;
   
   if (world->selected_index != -1)
   {
      tile = world->tiles + world->selected_index;
      draw_text_shadowed(render_commands, 
                         0xffffffff, 
                         0xff000000,
                         info_box_x,
                         info_box_y,
                         1,
                         "SELECTED\n"
                         "> %s(%d)\n"
                         "> %s(%d)",
                         kTileBaseString[tile->base],
                         tile->base_sprite_index,
                         kTileFloraString[tile->flora],
                         tile->flora_sprite_index);
      info_box_y += kNewLineAdvanceY * 4;
   }
}
